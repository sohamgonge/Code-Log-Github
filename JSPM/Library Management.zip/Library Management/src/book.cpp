#include<iostream>
#include<fstream>
#include<book.h>

book :: book(string ptitle, string pauthor, string pgenre, int ptcopies, int pacopies){
    title = ptitle;
    author = pauthor;
    genre = pgenre;
    tcopies = ptcopies;
    acopies = pacopies;
}