#include <iostream>
#include <fstream>
#include <library.h>
#include <member.h>
#include <book.h>
using namespace std;

int main()
{
    return 0;
}